/**
 * @author Shashi Vishwakarma
 * @project DataFabric
 * @date 9th June 2018
 */


package com.scb.datafabric.processors.hadoopDataMover;

import com.scb.datafabric.processors.hadoopDataMover.support.InformationEncryptor;


import com.fasterxml.jackson.databind.MappingIterator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import com.fasterxml.jackson.dataformat.xml.util.DefaultXmlPrettyPrinter;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import org.apache.nifi.components.AllowableValue;
import org.apache.nifi.components.PropertyDescriptor;
import org.apache.nifi.flowfile.FlowFile;
import org.apache.nifi.processor.*;
import org.apache.nifi.annotation.behavior.ReadsAttribute;
import org.apache.nifi.annotation.behavior.ReadsAttributes;
import org.apache.nifi.annotation.behavior.WritesAttribute;
import org.apache.nifi.annotation.behavior.WritesAttributes;
import org.apache.nifi.annotation.lifecycle.OnScheduled;
import org.apache.nifi.annotation.documentation.CapabilityDescription;
import org.apache.nifi.annotation.documentation.SeeAlso;
import org.apache.nifi.annotation.documentation.Tags;
import org.apache.nifi.processor.exception.ProcessException;
import org.apache.nifi.processor.io.StreamCallback;
import org.apache.nifi.processor.util.StandardValidators;


import java.io.*;
import java.nio.charset.Charset;
import java.util.*;

@Tags({"csv", "parse", "masking", "mask", "tokenize", "encrypt"})
@CapabilityDescription("Provide a description")
@SeeAlso({})
@ReadsAttributes({@ReadsAttribute(attribute="", description="")})
@WritesAttributes({@WritesAttribute(attribute="", description="")})
public class HadoopDataMoverLauncher extends AbstractProcessor {

	public static final AllowableValue DEFAULT = new AllowableValue(
			"DEFAULT", "DEFAULT", "Standard comma separated format.");
	
	public static final PropertyDescriptor FORMAT = new PropertyDescriptor
			.Builder().name("CSV Format")
			.description("Example Property")
			.required(true)
			.defaultValue(DEFAULT.getValue())
			.allowableValues(DEFAULT)
			.addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
			.build();

	public static final PropertyDescriptor COLUMN_ENCRYPT = new PropertyDescriptor
			.Builder().name("Column Encrypt")
			.description("Example Property")
			.required(true)
			.addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
			.expressionLanguageSupported(true)
			.build();

	public static final PropertyDescriptor DELIMITER = new PropertyDescriptor
			.Builder().name("File Delimiter")
			.description("Example Property")
			.required(true)
			.defaultValue(",")
			.addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
			.build();

	public static final PropertyDescriptor WITH_HEADER = new PropertyDescriptor
			.Builder().name("With Header")
			.description("Does CSV contains Header")
			.required(true)
			.defaultValue("True")
			.allowableValues("True", "False")
			.addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
			.build();
	public static final PropertyDescriptor CUSTOME_HEADER = new PropertyDescriptor
			.Builder().name("Custome Header")
			.description("Provide customer header for CSV")
			.required(false)
			.addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
			.build();
	public static final PropertyDescriptor OUTPUT_FORMAT = new PropertyDescriptor
			.Builder().name("Standard Output Format")
			.description("")
			.required(false)
			.defaultValue("CSV")
			.allowableValues("CSV")
			.addValidator(StandardValidators.NON_EMPTY_VALIDATOR)
			.build();

	

	public static final Relationship RELATIONSHIP_SUCCESS = new Relationship.Builder()
			.name("success")
			.description("success")
			.build();
	public static final Relationship RELATIONSHIP_FAILURE = new Relationship.Builder()
			.name("failure")
			.description("failure")
			.build();
	
	private List<PropertyDescriptor> descriptors;

	private Set<Relationship> relationships;

	@Override
	protected void init(final ProcessorInitializationContext context) {
		final List<PropertyDescriptor> descriptors = new ArrayList<PropertyDescriptor>();
		descriptors.add(FORMAT);

		descriptors.add(DELIMITER);
		descriptors.add(WITH_HEADER);
		descriptors.add(CUSTOME_HEADER);
		descriptors.add(OUTPUT_FORMAT);
		descriptors.add(COLUMN_ENCRYPT);
		this.descriptors = Collections.unmodifiableList(descriptors);

		final Set<Relationship> relationships = new HashSet<Relationship>();
		relationships.add(RELATIONSHIP_SUCCESS);
		relationships.add(RELATIONSHIP_FAILURE);

		this.relationships = Collections.unmodifiableSet(relationships);
	}

	@Override
	public Set<Relationship> getRelationships() {
		return this.relationships;
	}

	@Override
	public final List<PropertyDescriptor> getSupportedPropertyDescriptors() {
		return descriptors;
	}

	@OnScheduled
	public void onScheduled(final ProcessContext context) {
	}

	@Override
	public void onTrigger(final ProcessContext context, final ProcessSession session) throws ProcessException {

		final Charset charset = Charset.defaultCharset();
		FlowFile flowFile = session.get();
		if (flowFile == null) {
			return;
		}

		InformationEncryptor informationEncryptor = new InformationEncryptor();


		// TODO implement
		final Map<String, String> attributes = new LinkedHashMap<>();
		final String format = context.getProperty(FORMAT).getValue();
		final char delimiter = context.getProperty(DELIMITER).getValue().charAt(0);
		final boolean with_header = Boolean.parseBoolean(context.getProperty(WITH_HEADER).getValue());
		final String output_format = context.getProperty(OUTPUT_FORMAT).getValue();
		final String column_encrypt = context.getProperty(COLUMN_ENCRYPT).evaluateAttributeExpressions(flowFile).getValue();  
		final String encryptionKey = "#a*r123&5Bar%234";
		final String custom_header = context.getProperty(CUSTOME_HEADER).getValue();
		
		flowFile = session.write(flowFile, new StreamCallback() {
			@Override
			public void process(InputStream inputStream, OutputStream outputStream) throws IOException {

				CSVFormat csvFormat = buildFormat(format, delimiter, with_header, custom_header);
				CSVParser csvParser = new CSVParser(new InputStreamReader(inputStream, charset), csvFormat);
				CSVPrinter csvPrinter = new CSVPrinter(new OutputStreamWriter(outputStream, charset), csvFormat);
				String headerArray[];

				
				ArrayList<String> columnMaskList = new ArrayList<>();
				ArrayList<String> columnEncryptList = new ArrayList<String>();
				ArrayList<String> columnTokenizeList = new ArrayList<String>();

				List<String> maskValueHolder = new LinkedList<>();
				// FlowFile tokenized = session.create();

				//				// print header if needed
				//				if (custom_header != null && output_format.equals("CSV") && static_schema == null) {
				//					csvPrinter.printRecord(custom_header);
				//					headerArray = custom_header.split(",");
				//				}
				//				else 

				
				//System.out.println("Customer Header if Available " + custom_header.toString());
				if (custom_header != null)
				{
					//csvPrinter.printRecord(custom_header.replace("\"",""));
					headerArray = custom_header.split(",");
					System.out.println("Found Custom Header " + headerArray.toString());
				}
				else {
					
					
					headerArray = csvParser.getHeaderMap().keySet().toArray(new String[0]);
					csvPrinter.printRecord(headerArray);
//					
//					for( int i = 0; i < headerArray.length - 1; i++)
//					{
//					    String element = headerArray[i];
//					    System.out.println("Header Found - " + element);
//
//					}
//					
					
				}

			if (column_encrypt != null) {
					columnEncryptList =
							new ArrayList<>(Arrays.asList(column_encrypt.split(",")));
				}

			System.out.println("Debug Mode : Column list to be encrypted " + column_encrypt);
			
			
			// loop through records and print
				for (final CSVRecord record : csvParser) {

					Map<String, String> k = record.toMap();

//					for (Map.Entry<String,String> konj: k.entrySet())
//					{
//						//System.out.println(konj.getValue());
//					}
					// generate attributes if required per record

					// check masked columns
					if ( column_encrypt != null) {
						// we have to loop through the header array and match user requested mask columns
						for (int i = 0; i < headerArray.length; i++) {
							//System.out.println(headerArray[i] + "." + record.getRecordNumber() + "------>" + record.get(i));


							if (columnEncryptList.contains(headerArray[i])) {
								// encrypt
							//	System.out.println("================= Before Encrypting====================");
								maskValueHolder.add(new String(informationEncryptor.Encrypt( record.get(i), encryptionKey), "UTF-8"));
							//	System.out.println("================= After Encrypting =====================");
							}
							else {
								// no mask
								maskValueHolder.add(record.get(i));
							}
						}
						csvPrinter.printRecord(maskValueHolder);
						// clear mask column holder
						maskValueHolder.clear();
					}
					else {
						// no masking or encryption required, print record
						switch (output_format) {
						case "CSV":
							//csvPrinter.printRecord(record);
							List<String> items = Arrays.asList(custom_header.split(","));
							String lastColumn = items.get(items.size() - 1);
							String test = "";
							for (String item: items)
							{
								if (item != lastColumn) {
									test += record.get(item) + ",";
								}
								else {
									test += record.get(item);
								}
							}

							csvPrinter.printRecord(test.replace("^\"|\"$", ""));
							break;

						}
					}
				}
				csvPrinter.flush();
				csvPrinter.close();

			}
		});

		flowFile = session.putAllAttributes(flowFile, attributes);
		session.transfer(flowFile, RELATIONSHIP_SUCCESS);

	}



	public static List<Map<?, ?>> readObjectsFromCsv(InputStream is) throws IOException {
		CsvSchema bootstrap = CsvSchema.emptySchema().withHeader();
		CsvMapper csvMapper = new CsvMapper();
		MappingIterator<Map<?, ?>> mappingIterator = csvMapper.reader(Map.class).with(bootstrap).readValues(is);

		return mappingIterator.readAll();
	}




	private CSVFormat buildFormat(String format, char delimiter, Boolean with_header, String custom_header) {
		CSVFormat csvFormat = null;

		// set pre built format
		if (format.equals("DEFAULT")) {
			csvFormat = CSVFormat.DEFAULT;
		} 


		csvFormat = csvFormat.withHeader();
		
		
//		if (with_header & custom_header != null) {
//			csvFormat = csvFormat.withSkipHeaderRecord(true);
//			csvFormat = csvFormat.withHeader(custom_header);
//		} else if (with_header & custom_header == null) {
//			csvFormat = csvFormat.withHeader();
//		}

		if (delimiter > 0) {
			csvFormat = csvFormat.withDelimiter(delimiter);
		}
		return csvFormat;
	}
}
