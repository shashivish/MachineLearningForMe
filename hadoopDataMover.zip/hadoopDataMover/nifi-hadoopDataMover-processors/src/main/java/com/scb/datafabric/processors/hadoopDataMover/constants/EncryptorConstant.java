package com.scb.datafabric.processors.hadoopDataMover.constants;

public class EncryptorConstant {

	
	 public static final String ENCRYPTION_KEY = "#a*r123&5Bar%234";
	 public static final String CIPHER_KEY= "AES/CBC/PKCS5Padding";
	 public static final String ENCRYPTION_ALGORITHM =" AES";
	   
	 
}
