package com.scb.datafabric.processors.hadoopDataMover.support;

import com.scb.datafabric.processors.hadoopDataMover.constants.EncryptorConstant;

import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class InformationEncryptor {

	private static final Log LOG = LogFactory.getLog(InformationEncryptor.class);

	public byte[] Encrypt(String data, String key)
	{
		byte[] returnEncrypted = null;
		try {

			/**
			 * Create Key and Cipher for Encryption.
			 */
			Key aesKey = new SecretKeySpec(key.getBytes(), EncryptorConstant.ENCRYPTION_ALGORITHM);
			Cipher cipher = Cipher.getInstance(EncryptorConstant.CIPHER_KEY);

			/**
			 * Encrypt Incoming FlowFile Text.
			 */
			cipher.init(Cipher.ENCRYPT_MODE, aesKey);
			returnEncrypted = cipher.doFinal(Base64.encodeBase64(data.getBytes()));
		}
		catch(Exception e) {
			e.printStackTrace();
			LOG.error("Unable to Encrypt Information " + key +" ." + e.getMessage() );

		}
		return Base64.encodeBase64(returnEncrypted);
	}

}
