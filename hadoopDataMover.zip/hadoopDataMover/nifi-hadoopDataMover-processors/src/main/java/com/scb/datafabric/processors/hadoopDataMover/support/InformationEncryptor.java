package com.scb.datafabric.processors.hadoopDataMover.support;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class InformationEncryptor {


	public byte[] Encrypt(String data, String key) {
		byte[] returnEncrypted = null;
		try {
			// Create key and cipher
			Key aesKey = new SecretKeySpec(key.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");

			// encrypt the text
			cipher.init(Cipher.ENCRYPT_MODE, aesKey);
			returnEncrypted = cipher.doFinal(Base64.encodeBase64(data.getBytes()));
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return Base64.encodeBase64(returnEncrypted);
	}

}
